var qmodule=angular.module("myapp",[]);

qmodule.factory("EmployeeService",function($http,$q){
	//factory registers the service
	
	return {
		
		retriveEmployee:function(){
			
			var def=$q.defer();
			
			
			$http({
				method:'GET',
				url:"EmployeeData.json"
			}).success(function(data,status,header,config){		//succee is called directly on succes of the prev fn
				
				def.resolve(); // data succesfully received
			}).error(function(data,status,header,config){
				
				def.reject();
			});
			
			return def.promise;	//promise returns true/false
		}
	}
});