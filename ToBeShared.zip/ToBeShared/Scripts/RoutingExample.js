var app=angular.module("RouteApp",['ngRoute']);

app.controller("RoutingController",function())

app.config(function($routeProvider,$locationProvider){
	//information about routes should be registered in routeProvider
	$routeProvider.when('/',{
		template:"<h1>Welcome Route</h1>"
		
	}).
	when('/state',{
		template:"<h2>Maharashtra</h2>"
	}).
	when('/state/city',{
		template:"<h1>City: Pune</h1>"
	}).
	when('/coutry',{
		template:"<h1>India</h1>"
	}).
	otherwise({
		redirectTo:"/"
	})
});