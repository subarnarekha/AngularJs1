var myapp=angular.module("Rest",[]);

myapp.controller("RestController",function($scope,$http){
	
	var result=$http.get("http://10.219.34.92:8088/Demo_1/igate/greet");
	
	result.then(function(response){
		
		$scope.serverResp=response.data;
		
	});
});