var mymodule=angular.module("CustomDirective",[]);

mymodule.directive("mouseentry",function(){

	return{
		
		//No restrict given , deault for restrict is A
		link:function(scope,element,attrs){
		
			element.bind("mouseenter",function(){
			element.addClass(attrs.datastyle);
			});
		
		}
	}
});


mymodule.directive("mouseleft",function(){

	return{
		
		//No restrict given , deault for restrict is A
		link:function(scope,element,attrs){
		
			element.bind("mouseleave",function(){
			element.removeClass(attrs.datastyle);
			});
		
		}
	}
});