var mymodule=angular.module("DirectiveApp",[]);


//directive names should be in lowercase
mymodule.directive("helloworldelement",function(){
	
	return {
		//restrict indicates this directive will be used as element only 
		restrict:'E',
		template:'Hello World for <b>Element</b> from Directive'
	}
});


mymodule.directive("helloworldattribute",function(){
	
	return {
		//restrict indicates this directive will be used as element only 
		restrict:'A',
		template:'Hello World for <b>Attribute</b> from Directive'
	}
});

mymodule.directive("helloworldclass",function(){
	
	return {
		//restrict indicates this directive will be used as element only 
		restrict:'C',
		template:'Hello World for <b>Class</b> from Directive'
	}
});

mymodule.directive("helloworldcomments",function(){
	
	return {
		//restrict indicates this directive will be used as element only 
		restrict:'M',
		replace:true,
		template:'<p>Hello World for Comments from Directive</p>'
	}
});