var app=angular.module("myfirst",[]);	// dependent modules are specified in []
	
	app.controller("HelloWorldController",function($scope,$rootScope){
		
		$rootScope.name="Capgemini";
		
		$scope.greetingmsg="Welcome to Angular world";
		
		$scope.employee={"Id":101,"Name":"Ram","Salary":45000}
		
		$scope.guests=[
		{"GuestId":101,"GuestName":"Raj","GuestContNumber":"9879879876"},
		{"GuestId":102,"GuestName":"Ram","GuestContNumber":"9879879876"},
		{"GuestId":103,"GuestName":"Rai","GuestContNumber":"9879879876"}
		];
						
	});